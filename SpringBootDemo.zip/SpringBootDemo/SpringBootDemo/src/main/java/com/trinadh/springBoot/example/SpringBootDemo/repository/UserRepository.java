package com.trinadh.springBoot.example.SpringBootDemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trinadh.springBoot.example.SpringBootDemo.entity.User;



//public interface UserRepository {
//
//}
//




public interface UserRepository extends JpaRepository<User, Integer>{
	User findByUserId(int id);

}
